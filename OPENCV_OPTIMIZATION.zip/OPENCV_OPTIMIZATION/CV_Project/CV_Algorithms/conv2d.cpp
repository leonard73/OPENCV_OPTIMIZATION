/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#include "../CV_Algorithms/conv2d.h"

void do_CVAlgo_Conv2D(void * param)
{
	struct CV_Algo_Conv2D_Param * params = (struct CV_Algo_Conv2D_Param *)param;
	cv::filter2D(*params->src_Mat,*params->dst_Mat,params->dataDepth,*params->kernel_Mat,params->anchor,params->delta,params->borderType);
}
