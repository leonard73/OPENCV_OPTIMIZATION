/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#include"../CV_Algorithms/warpAffine.h"
void doImageResize(void * param)
{
	struct imageResizeParam * parmas = (struct imageResizeParam *)param;
	cv::resize(*parmas->src_Mat, *parmas->dst_Mat, parmas->dsize, parmas->ratio_Horizon, parmas->ratio_Vertical, parmas->interpolation_Model);
}
/********************rotateCode:---1 90 clockwise  *****************************/
/********************rotateCode:---2 180 clockwise ****1************************/
/********************rotateCode:---3 270 clockwise *****************************/
void doImageRotate(void * param)
{
	struct imageRotateParam * parmas = (struct imageRotateParam *)param;
	cv::rotate(*parmas->src_Mat, *parmas->dst_Mat, parmas->rotateCode);
}
/********************flipCode:>0 y axis     *****************************/
/********************flipCode:=0 x axis     *****************************/
/********************flipCode:<0 x & y axis *****************************/
void doImageFlip(void * param)
{
	struct imageFlipParam * parmas = (struct imageFlipParam *)param;
	cv::flip(*parmas->src_Mat, *parmas->dst_Mat, parmas->flipCode);
}