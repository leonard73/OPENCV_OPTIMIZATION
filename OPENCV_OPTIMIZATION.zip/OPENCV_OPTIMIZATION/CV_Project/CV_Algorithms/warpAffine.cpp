/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#include"../CV_Algorithms/warpAffine.h"
void doImageWarpAffine(void * param)
{
	struct imageWarpAffineParam * parmas = (struct imageWarpAffineParam *)param;
	cv::resize(*parmas->src_Mat, *parmas->dst_Mat, parmas->dsize, parmas->ratio_Horizon, parmas->ratio_Vertical, parmas->interpolation_Model);
}