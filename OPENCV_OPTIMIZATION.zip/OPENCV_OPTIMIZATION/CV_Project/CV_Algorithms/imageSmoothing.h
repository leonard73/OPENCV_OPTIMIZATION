/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#ifndef _CV_ALGORITHMS_IMAGE_SMOOTHING_H_
#define _CV_ALGORITHMS_IMAGE_SMOOTHING_H_
#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

typedef struct CV_Algo_GaussBlur_Param
{
	cv::Mat *src_Mat;
	cv::Mat *dst_Mat;
	float sigmaX;
	float sigmaY;
	int dataDepth;
	cv::Point anchor=cv::Point(-1,-1);
	cv::Size stepSize;
	int borderType = 4;
};
typedef struct CV_Algo_AverageBlur_Param
{
	cv::Mat *src_Mat;
	cv::Mat *dst_Mat;
	int dataDepth;
	cv::Point anchor = cv::Point(-1, -1);
	cv::Size stepSize;
	bool normalize = true;
	int borderType = 4;
};
typedef struct CV_Algo_Blur_Param
{
	cv::Mat *src_Mat;
	cv::Mat *dst_Mat;
	int dataDepth;
	cv::Point anchor = cv::Point(-1, -1);
	cv::Size stepSize;
	int borderType = 4;
};
typedef struct CV_Algo_MedianBlur_Param
{
	cv::Mat *src_Mat;
	cv::Mat *dst_Mat;
	int dataDepth;
	cv::Point anchor = cv::Point(-1, -1);
	int stepSize;
	int borderType = 4;
};
typedef struct CV_Algo_BilaterFilter_Param
{
	cv::Mat *src_Mat;
	cv::Mat *dst_Mat;
	int d=3;
	double sigmaColor;
	double sigmaSpace;
	int borderType = 4;
};
void do_CVAlgo_GaussBlur(void * param);
void do_CVAlgo_AverageBlur(void * param);
void do_CVAlgo_Blur(void * param);
void do_CVAlgo_MedianBlur(void * param);
void do_CVAlgo_BilaterFilter(void *param);
#endif