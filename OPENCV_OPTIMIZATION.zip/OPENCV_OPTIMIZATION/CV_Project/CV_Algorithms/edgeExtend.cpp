/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#include "../CV_Algorithms/edgeExtend.h"


void doCV_ALGO_EdgeExtend(void * param)
{
	struct CV_Algorithms_Edge_Extend_Param * params = (struct CV_Algorithms_Edge_Extend_Param *)param;
	cv::copyMakeBorder(*params->src_Mat,*params->dst_Mat,params->topLines,params->bottomLines,params->leftLines,params->rightLines,params->borderType);
}