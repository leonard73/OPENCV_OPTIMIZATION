/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#ifndef _CV_ALGORITHMS_WARPAFFINE_H_
#define _CV_ALGORITHMS_WARPAFFINE_H_
#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>
typedef struct imageResizeParam
{
	cv::Mat *src_Mat;
	cv::Mat *dst_Mat;
	cv::Size dsize;
	double ratio_Horizon;
	double ratio_Vertical;
	int interpolation_Model;
};
typedef struct imageRotateParam
{
	cv::Mat *src_Mat;
	cv::Mat *dst_Mat;
	int rotateCode;
};
typedef struct imageFlipParam
{
	cv::Mat *src_Mat;
	cv::Mat *dst_Mat;
	int flipCode;
};
void doImageResize(void * param);
void doImageRotate(void * param);
void doImageFlip(void * param);
#endif