/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#include "../CV_Algorithms/imageSmoothing.h"

void do_CVAlgo_GaussBlur(void * param)
{
	struct CV_Algo_GaussBlur_Param * params = (struct CV_Algo_GaussBlur_Param *)param;
	cv::GaussianBlur(*params->src_Mat,*params->dst_Mat,params->stepSize,params->sigmaX,params->sigmaY,params->borderType);
}
void do_CVAlgo_AverageBlur(void * param)
{
	struct CV_Algo_AverageBlur_Param * params = (struct CV_Algo_AverageBlur_Param *)param;
	cv::boxFilter(*params->src_Mat,*params->dst_Mat,params->dataDepth,params->stepSize,params->anchor,params->normalize,params->borderType);
}
void do_CVAlgo_Blur(void * param)
{
	struct CV_Algo_Blur_Param * params = (struct CV_Algo_Blur_Param *)param;
	cv::blur(*params->src_Mat, *params->dst_Mat,params->stepSize, params->anchor,params->borderType);
}
void do_CVAlgo_MedianBlur(void * param)
{
	struct CV_Algo_MedianBlur_Param * params = (struct CV_Algo_MedianBlur_Param *)param;
	cv::medianBlur(*params->src_Mat,*params->dst_Mat,params->stepSize);
}
void do_CVAlgo_BilaterFilter(void *param)
{
	struct CV_Algo_BilaterFilter_Param * params = (struct CV_Algo_BilaterFilter_Param *)param;
	cv::bilateralFilter(*params->src_Mat,*params->dst_Mat,params->d,params->sigmaColor,params->sigmaSpace,params->borderType);
}