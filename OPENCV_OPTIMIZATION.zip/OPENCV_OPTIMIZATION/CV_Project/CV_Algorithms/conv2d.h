/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#ifndef _CV_ALGORITHMS_CONV2D_H_
#define _CV_ALGORITHMS_CONV2D_H_
#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

typedef struct CV_Algo_Conv2D_Param
{
	cv::Mat *src_Mat;
	cv::Mat *dst_Mat;
	cv::Mat *kernel_Mat;
	int dataDepth;
	cv::Point anchor;
	double delta=0.0;
	int borderType=4;
};
void do_CVAlgo_Conv2D(void * param);

#endif