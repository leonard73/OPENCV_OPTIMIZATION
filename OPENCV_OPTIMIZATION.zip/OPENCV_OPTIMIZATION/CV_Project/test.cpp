/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#include "../CV_Project//Module Tests/CVBasicTest.h"
#include "../CV_Project/Module Tests/CVAlgorithmsTest.h"
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "test.h"

int main()
{
	
	//CVBasicTest();
	CVAlgorithmsTest();
	return 0;
}