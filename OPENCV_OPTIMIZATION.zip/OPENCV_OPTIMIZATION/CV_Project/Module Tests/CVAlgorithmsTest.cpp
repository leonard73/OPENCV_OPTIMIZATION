/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#include "../CV_Basics/ReadAndSave.h"
#include "../Module Tests/CVAlgorithmsTest.h"
#include "../CV_Algorithms/warpAffine.h"
#include "../CV_Algorithms/edgeExtend.h"
#include "../CV_Algorithms/conv2d.h"
#include "../CV_Algorithms/imageSmoothing.h"
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>


void CVAlgoImageResize()
{
	const cv::String path_in = "DATA/lena.jpg";
	const cv::String path_out = "DATA/lena_ImageWarpAffineResultResize.jpg";
	struct imageResizeParam *WarpAffineParam = (struct imageResizeParam*)malloc(sizeof(struct imageResizeParam));
	cv::Mat readMat,outMat;

	int i = CVBasic_ReadImageInMat(path_in, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	WarpAffineParam->src_Mat = &readMat;
	WarpAffineParam->dst_Mat = &outMat;
	WarpAffineParam->dsize = cv::Size(readMat.cols/2,readMat.rows/2);
	WarpAffineParam->ratio_Horizon = 0.5;
	WarpAffineParam->ratio_Vertical = 0.5;
	WarpAffineParam->interpolation_Model = cv::INTER_LINEAR;
	doImageResize((void *)WarpAffineParam);
	cv::imshow("resize half", outMat);
	cv::waitKey(0);
	i = CVBasic_SaveImageFromMat(path_out, &outMat);
}
void CVAlgoImageRotate()
{
	const cv::String path_in = "DATA/lena.jpg";
	const cv::String path_out = "DATA/lena_ImageWarpAffineResultRotate.jpg";
	struct imageRotateParam *WarpAffineParam = (struct imageRotateParam*)malloc(sizeof(struct imageRotateParam));
	cv::Mat readMat, outMat;

	int i = CVBasic_ReadImageInMat(path_in, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	WarpAffineParam->src_Mat = &readMat;
	WarpAffineParam->dst_Mat = &outMat;
	WarpAffineParam->rotateCode = 2;//rotate 180
	doImageRotate((void *)WarpAffineParam);
	cv::imshow("rotate 180", outMat);
	cv::waitKey(0);
	i = CVBasic_SaveImageFromMat(path_out, &outMat);
}
void CVAlgoImageFlip()
{
	const cv::String path_in = "DATA/lena.jpg";
	const cv::String path_out = "DATA/lena_ImageWarpAffineResultFlip.jpg";
	struct imageFlipParam *WarpAffineParam = (struct imageFlipParam*)malloc(sizeof(struct imageFlipParam));
	cv::Mat readMat, outMat;

	int i = CVBasic_ReadImageInMat(path_in, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	WarpAffineParam->src_Mat = &readMat;
	WarpAffineParam->dst_Mat = &outMat;
	WarpAffineParam->flipCode = 0;//x&y axis
	doImageFlip((void *)WarpAffineParam);
	cv::imshow("flip x&y", outMat);
	cv::waitKey(0);
	i = CVBasic_SaveImageFromMat(path_out, &outMat);
}
void CVAlgoEdgeExtend()
{
	const cv::String path_in = "DATA/lena.jpg";
	const cv::String path_out = "DATA/lena_EdgeExtend.jpg";
	struct CV_Algorithms_Edge_Extend_Param *EdgeExtendParam = (struct CV_Algorithms_Edge_Extend_Param*)malloc(sizeof(struct CV_Algorithms_Edge_Extend_Param));
	cv::Mat readMat, outMat;

	int i = CVBasic_ReadImageInMat(path_in, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	EdgeExtendParam->src_Mat = &readMat;
	EdgeExtendParam->dst_Mat = &outMat;
	EdgeExtendParam->topLines = 10;
	EdgeExtendParam->bottomLines = 10;
	EdgeExtendParam->leftLines = 10;
	EdgeExtendParam->rightLines = 10;
	EdgeExtendParam->borderType = cv::BORDER_REPLICATE;
	doCV_ALGO_EdgeExtend((void *)EdgeExtendParam);
	cv::imshow("EdgeExtend 10", outMat);
	cv::waitKey(0);
	i = CVBasic_SaveImageFromMat(path_out, &outMat);
}
void CVAlgoConv2D()
{
	const cv::String path_in = "DATA/lena.jpg";
	const cv::String path_out = "DATA/lena_Conv2D.jpg";
	struct CV_Algo_Conv2D_Param *Conv2DParam = (struct CV_Algo_Conv2D_Param*)malloc(sizeof(struct CV_Algo_Conv2D_Param));
	cv::Mat readMat, outMat;
	cv::Mat kernelMat = (cv::Mat_<char>(3, 3) << 1, 2, 1, 2, 4, 2, 1, 2, 1);
	int i = CVBasic_ReadImageInMat(path_in, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	Conv2DParam->src_Mat = &readMat;
	Conv2DParam->dst_Mat = &outMat;
	Conv2DParam->kernel_Mat = &kernelMat;
	Conv2DParam->dataDepth = CV_16S;
	Conv2DParam->delta = 0;
	Conv2DParam->borderType = cv::BORDER_REPLICATE;
	Conv2DParam->anchor = cv::Point(0, 0);
	do_CVAlgo_Conv2D((void *)Conv2DParam);
	cv::imshow("Conv2D", outMat);
	cv::waitKey(0);
	i = CVBasic_SaveImageFromMat(path_out, &outMat);
}
void CVAlgoGaussBlur()
{
	const cv::String path_in = "DATA/lena.jpg";
	const cv::String path_out = "DATA/lena_Gauss5x5.jpg";
	struct CV_Algo_GaussBlur_Param *GaussBlurParam = (struct CV_Algo_GaussBlur_Param*)malloc(sizeof(struct CV_Algo_GaussBlur_Param));
	cv::Mat readMat, outMat;
	cv::Size stepSize(5, 5);
	int i = CVBasic_ReadImageInMat(path_in, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	GaussBlurParam->src_Mat = &readMat;
	GaussBlurParam->dst_Mat = &outMat;
	GaussBlurParam->dataDepth = CV_8U;
	GaussBlurParam->sigmaX = 1.4;
	GaussBlurParam->sigmaY = 1.4;
	GaussBlurParam->borderType = cv::BORDER_REPLICATE;
	GaussBlurParam->anchor = cv::Point(-1, -1);
	GaussBlurParam->stepSize = stepSize;
	do_CVAlgo_GaussBlur((void *)GaussBlurParam);
	cv::imshow("Gauss", outMat);
	cv::waitKey(0);
	i = CVBasic_SaveImageFromMat(path_out, &outMat);
}
void CVAlgoAverageBlur()
{
	const cv::String path_in = "DATA/lena.jpg";
	const cv::String path_out = "DATA/lena_Average5x5.jpg";
	struct CV_Algo_AverageBlur_Param *AverageBlurParam = (struct CV_Algo_AverageBlur_Param*)malloc(sizeof(struct CV_Algo_AverageBlur_Param));
	cv::Mat readMat, outMat;
	cv::Size stepSize(5, 5);
	int i = CVBasic_ReadImageInMat(path_in, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	AverageBlurParam->src_Mat = &readMat;
	AverageBlurParam->dst_Mat = &outMat;
	AverageBlurParam->dataDepth = CV_8U;
	AverageBlurParam->normalize = true;
	AverageBlurParam->borderType = cv::BORDER_REPLICATE;
	AverageBlurParam->anchor = cv::Point(-1, -1);
	AverageBlurParam->stepSize = stepSize;
	do_CVAlgo_AverageBlur((void *)AverageBlurParam);
	cv::imshow("Average5x5", outMat);
	cv::waitKey(0);
	i = CVBasic_SaveImageFromMat(path_out, &outMat);
}
void CVAlgoBlur()
{
	const cv::String path_in = "DATA/lena.jpg";
	const cv::String path_out = "DATA/lena_Blur5x5.jpg";
	struct CV_Algo_Blur_Param *BlurParam = (struct CV_Algo_Blur_Param*)malloc(sizeof(struct CV_Algo_Blur_Param));
	cv::Mat readMat, outMat;
	cv::Size stepSize(5, 5);
	int i = CVBasic_ReadImageInMat(path_in, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	BlurParam->src_Mat = &readMat;
	BlurParam->dst_Mat = &outMat;
	BlurParam->dataDepth = CV_8U;
	BlurParam->borderType = cv::BORDER_REPLICATE;
	BlurParam->anchor = cv::Point(-1, -1);
	BlurParam->stepSize = stepSize;
	do_CVAlgo_Blur((void *)BlurParam);
	cv::imshow("Blur5x5", outMat);
	cv::waitKey(0);
	i = CVBasic_SaveImageFromMat(path_out, &outMat);
}
void CVAlgoMedianBlur()
{
	const cv::String path_in = "DATA/lena.jpg";
	const cv::String path_out = "DATA/lena_MedianBlur5x5.jpg";
	struct CV_Algo_MedianBlur_Param *MedianBlurParam = (struct CV_Algo_MedianBlur_Param*)malloc(sizeof(struct CV_Algo_MedianBlur_Param));
	cv::Mat readMat, outMat;
	cv::Size stepSize(5, 5);
	int i = CVBasic_ReadImageInMat(path_in, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	MedianBlurParam->src_Mat = &readMat;
	MedianBlurParam->dst_Mat = &outMat;
	MedianBlurParam->dataDepth = CV_8U;
	MedianBlurParam->borderType = cv::BORDER_REPLICATE;
	MedianBlurParam->anchor = cv::Point(-1, -1);
	MedianBlurParam->stepSize = 5;
	do_CVAlgo_MedianBlur((void *)MedianBlurParam);
	cv::imshow("Median Blur5x5", outMat);
	cv::waitKey(0);
	i = CVBasic_SaveImageFromMat(path_out, &outMat);
}
void CVAlgoBilaterBlur()
{
	const cv::String path_in = "DATA/lena.jpg";
	const cv::String path_out = "DATA/lena_BilaterBlur5x5.jpg";
	struct CV_Algo_BilaterFilter_Param *BilaterBlurParam = (struct CV_Algo_BilaterFilter_Param*)malloc(sizeof(struct CV_Algo_BilaterFilter_Param));
	cv::Mat readMat, outMat;
	int i = CVBasic_ReadImageInMat(path_in, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	BilaterBlurParam->src_Mat = &readMat;
	BilaterBlurParam->dst_Mat = &outMat;
	BilaterBlurParam->d = 50;
	BilaterBlurParam->borderType = cv::BORDER_REPLICATE;
	BilaterBlurParam->sigmaColor = 50;
	BilaterBlurParam->sigmaSpace = 50;
	do_CVAlgo_BilaterFilter((void *)BilaterBlurParam);
	cv::imshow("Bilater Blur5x5", outMat);
	cv::waitKey(0);
	i = CVBasic_SaveImageFromMat(path_out, &outMat);
}
int CVAlgosTest()
{
	int ret = 0;
	//	ret = CVBasic_ReadImageInMatTest();
	//CVAlgoImageResize();
	//CVAlgoImageRotate();
	//CVAlgoImageFlip();
	//CVAlgoEdgeExtend();
	//CVAlgoConv2D();
	//CVAlgoGaussBlur();
	//CVAlgoBlur();
	//CVAlgoAverageBlur();
	CVAlgoBilaterBlur();
	//CVAlgoMedianBlur();
	return ret;
}