/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#include "../CV_Basics/ReadAndSave.h"
#include "../Module Tests/CVAlgorithmsTest.h"
#include "../CV_Algorithms/warpAffine.h"
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>


void CVAlgorithmsImageWarpAffineTest()
{
	const cv::String path_in = "DATA/lena.jpg";
	const cv::String path_out = "DATA/lena_ImageWarpAffineResult.jpg";
	struct imageWarpAffineParam *WarpAffineParam = (struct imageWarpAffineParam*)malloc(sizeof(struct imageWarpAffineParam));
	cv::Mat readMat,outMat;

	int i = CVBasic_ReadImageInMat(path_in, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	WarpAffineParam->src_Mat = &readMat;
	WarpAffineParam->dst_Mat = &outMat;
	WarpAffineParam->dsize = cv::Size(readMat.cols/2,readMat.rows/2);
	WarpAffineParam->ratio_Horizon = 0.5;
	WarpAffineParam->ratio_Vertical = 0.5;
	WarpAffineParam->interpolation_Model = cv::INTER_LINEAR;
	doImageWarpAffine((void *)WarpAffineParam);
	cv::imshow("resize half", outMat);
	cv::waitKey(0);
	i = CVBasic_SaveImageFromMat(path_out, &outMat);
}
int CVAlgorithmsTest()
{
	int ret = 0;
	//	ret = CVBasic_ReadImageInMatTest();
	CVAlgorithmsImageWarpAffineTest();
	return ret;
}