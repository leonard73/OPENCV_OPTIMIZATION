/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#include "../CV_Basics/ReadAndSave.h"
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>


int CVBasic_ReadImageInMatTest()
{
	const cv::String path = "DATA/lena.jpg";
	cv::Mat readMat;
	int i = CVBasic_ReadImageInMat(path, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	cv::imshow("lena", readMat);
	cv::waitKey(0);
	return 0;
}
int CVBasic_SaveImageFromMatTest()
{
	const cv::String path_in = "DATA/lena.jpg";
	const cv::String path_out = "DATA/lena_out.jpg";
	cv::Mat readMat;
	int i = CVBasic_ReadImageInMat(path_in, (cv::Mat *)&readMat, cv::IMREAD_ANYCOLOR);
	i = CVBasic_SaveImageFromMat(path_out, &readMat);
	return i;
}

int CVBasicTest()
{
	int ret = 0;
//	ret = CVBasic_ReadImageInMatTest();
	ret = CVBasic_SaveImageFromMatTest();
	return ret;
}