/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#pragma once
#ifndef _CV_BASICS_READ_AND_SAVE_
#define _CV_BASICS_READ_AND_SAVE_
#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
int CVBasic_ReadImageInMat(const cv::String srcPath, cv::Mat *outMat, int loadMode);
int CVBasic_SaveImageFromMat(const cv::String dstPath, cv::Mat *inMat);
#endif