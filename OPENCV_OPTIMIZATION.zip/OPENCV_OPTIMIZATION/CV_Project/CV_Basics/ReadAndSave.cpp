/***************************************************************COPY RIGHT*************************************************************
*********************This is OPEN SOURCE project to help developers to make research and use in open source projects*******************
************************************************************Author: PANJIAQI***********************************************************
************************************************************Date: Year2019 September 9th***********************************************
************************************************************Site: Shanghai XIUPU Road**************************************************
********************************************Anyone who wants to use thes codes should add this copyrights******************************
********************************************And any Project using these codes should be open source too********************************
***************************************************************************************************************************************
*/
#include"ReadAndSave.h"
int CVBasic_ReadImageInMat(const cv::String srcPath,cv::Mat *outMat,int loadMode)
{
	*outMat = cv::imread(srcPath, loadMode);
	return 0;
}
int CVBasic_SaveImageFromMat(const cv::String dstPath,cv::Mat *inMat)
{	
	cv::imwrite(dstPath, *inMat);
	return 0;
}